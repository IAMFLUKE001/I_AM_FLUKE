[![Github All Releases](https://img.shields.io/github/downloads/peter12908/PeterBOT/total.svg)]() 
<html>
  <head>
  </head>
  <body>
    <h1>PeterBot</h1>

PeterBot a Minecraft Bot Tool

<h2>PeterBot (Version 5.0.0-alpha)</h2>
<a href="https://www.youtube.com/watch?v=95oSpmI41tk"><img alt="YouTube Video Views" src="https://img.shields.io/youtube/views/95oSpmI41tk?style=social"></a>
<h3>Windows: <a href="https://github.com/peter12908/PeterBOT/releases/download/5.0.0/PeterBotV5-win32-x64.zip">Download</a></h3>

<h2>PeterBot (Version 4.0-alpha)</h2>
<a href="https://www.youtube.com/watch?v=G-uGHHArtXs"><img alt="YouTube Video Views" src="https://img.shields.io/youtube/views/G-uGHHArtXs?style=social"></a>
<h3>Windows: <a href="https://github.com/peter12908/PeterBOT/releases/download/v4.0-alpha/PeterBot-win32-x64.zip">Download</a></h3>

<h2>PeterBot (Version 3.0):</h2>
<a href="https://www.youtube.com/watch?v=hT-4OB2Cs6A"><img alt="YouTube Video Views" src="https://img.shields.io/youtube/views/hT-4OB2Cs6A?style=social"></a>
<h3>Windows: <a href="https://workupload.com/file/w8NzX5Y4">Download</a></h3>
<h3>Linux: <a href="https://workupload.com/file/rLCJTZqb">Download</a></h3>

<h2>PeterBot (Version 2.0):</h2>
<a href="https://www.youtube.com/watch?v=-IL9E8wsyHE"><img alt="YouTube Video Views" src="https://img.shields.io/youtube/views/-IL9E8wsyHE?style=social"></a>
<h3>Windows: <a href="https://workupload.com/file/zYTxdNcG">Download</a></h3>
</body>
</html>
